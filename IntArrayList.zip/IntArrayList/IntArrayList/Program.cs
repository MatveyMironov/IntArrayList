﻿internal class Program
{
    public static void Main(string[] args)
    {
        IntArrayList intArrayList = new IntArrayList(3);

        intArrayList.PushBack(1);
        intArrayList.PushBack(2);
        intArrayList.PushBack(3);
        Console.WriteLine(intArrayList.Count);
        Console.WriteLine(intArrayList.Capacity);
        Console.WriteLine("");

        int result;
        Console.WriteLine(intArrayList.TryGetAt(0, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(1, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(2, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(3, out result));
        Console.WriteLine(result);
        Console.WriteLine("");

        intArrayList.PopBack();
        Console.WriteLine(intArrayList.TryErase(0));
        Console.WriteLine(intArrayList.TryErase(2));
        Console.WriteLine(intArrayList.TryInsert(1, 100));
        Console.WriteLine("");

        Console.WriteLine(intArrayList.TryGetAt(0, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(1, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(2, out result));
        Console.WriteLine(result);
        Console.WriteLine("");

        intArrayList.PushBack(4);
        intArrayList.PushBack(5);
        Console.WriteLine(intArrayList.Count);
        Console.WriteLine(intArrayList.Capacity);
        Console.WriteLine("");

        Console.WriteLine(intArrayList.TryInsert(4, 6));
        Console.WriteLine(intArrayList.TryInsert(5, 6));
        Console.WriteLine(intArrayList.TryInsert(6, 6));
        Console.WriteLine("");

        Console.WriteLine(intArrayList.Count);
        Console.WriteLine(intArrayList.Capacity);
        Console.WriteLine(intArrayList.TryGetAt(4, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(5, out result));
        Console.WriteLine(result);
        Console.WriteLine(intArrayList.TryGetAt(6, out result));
        Console.WriteLine(result);
        Console.WriteLine("");

        Console.WriteLine(intArrayList.TryInsert(-10, 6));
        Console.WriteLine(intArrayList.TryInsert(10, 6));
        Console.WriteLine(intArrayList.TryErase(-10));
        Console.WriteLine(intArrayList.TryErase(10));
        Console.WriteLine("");

        Console.WriteLine(intArrayList.TryForceCapacity(-10));
        Console.WriteLine(intArrayList.TryForceCapacity(4));
        Console.WriteLine(intArrayList.Count);
        Console.WriteLine(intArrayList.Capacity);
        Console.WriteLine("");

        Console.WriteLine(intArrayList.Find(100));
        Console.WriteLine(intArrayList.Find(1000));
        Console.WriteLine("");

        intArrayList.Clear();
        Console.WriteLine(intArrayList.Count);
        Console.WriteLine(intArrayList.Capacity);
        Console.WriteLine("");
    }
}